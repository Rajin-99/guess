import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Word Guess',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Poppins', // Modern font
        primarySwatch: Colors.yellow,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => const UsernamePage()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.yellow.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "WORD",
                style: TextStyle(
                  fontFamily: 'RockSalt',
                  color: Colors.yellow.shade700,
                  fontSize: 70,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 6,
                ),
              ),
              const Text(
                "GUESS",
                style: TextStyle(
                  fontFamily: 'RockSalt',
                  color: Colors.white,
                  fontSize: 50,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 8,
                ),
              ),
              const SizedBox(height: 40),
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.yellow),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class UsernamePage extends StatefulWidget {
  const UsernamePage({super.key});

  @override
  _UsernamePageState createState() => _UsernamePageState();
}

class _UsernamePageState extends State<UsernamePage> {
  final TextEditingController _controller = TextEditingController();
  String username = '';
  int score = 0;

  void _startGame() {
    if (_controller.text.isNotEmpty) {
      setState(() {
        username = _controller.text;
      });
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HomePage(username: username, score: score)),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a username')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.yellow.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "Enter Your Username",
                  style: TextStyle(
                    fontSize: 28,
                    color: Colors.white,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _controller,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.6),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    hintText: 'Username',
                    hintStyle: const TextStyle(color: Colors.white),
                    prefixIcon: const Icon(Icons.person, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _startGame,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.yellow.shade700,
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    shadowColor: Colors.black,
                    elevation: 5,
                  ),
                  child: const Text(
                    'Start Game',
                    style: TextStyle(fontSize: 20, color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String username;
  final int score;
  const HomePage({super.key, required this.username, required this.score});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Map<String, String> wordHints = {
    'FLUTTER': 'A popular mobile UI framework.',
    'DART': 'A programming language.',
    'WIDGET': 'Building blocks of Flutter apps.',
    'STATE': 'Manages the behavior of widgets.',
    'BUILDER': 'Used to build widgets dynamically.',
  };

  late String wordToGuess;
  late String hint;
  List<String> guessedLetters = [];
  int wrongGuesses = 0;

  @override
  void initState() {
    super.initState();
    _startNewGame();
  }

  void _startNewGame() {
    setState(() {
      final entry = (wordHints.entries.toList()..shuffle()).first;
      wordToGuess = entry.key;
      hint = entry.value;
      guessedLetters.clear();
      wrongGuesses = 0;
    });
  }

  void _guessLetter(String guess) {
    if (guessedLetters.contains(guess)) return;

    setState(() {
      guessedLetters.add(guess);

      if (!wordToGuess.contains(guess)) {
        wrongGuesses++;
      }

      if (_getDisplayedWord().contains('_') == false) {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => WinPage(word: wordToGuess, username: widget.username, score: widget.score)));
      } else if (wrongGuesses == 6) {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => LossPage(word: wordToGuess, remainingAttempts: 0, username: widget.username, score: widget.score)));
      }
    });
  }

  String _getDisplayedWord() {
    return wordToGuess
        .split('')
        .map((letter) => guessedLetters.contains(letter) ? letter : '_')
        .join(' ');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          "Word Guess Game",
          style: TextStyle(color: Colors.yellow),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.yellow),
            onPressed: () {
              // Add settings navigation here
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.yellow.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Player: ${widget.username} | Score: ${widget.score}",
              style: const TextStyle(fontSize: 20, color: Colors.white),
            ),
            const SizedBox(height: 40),
            Card(
              color: Colors.yellow.shade700,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              elevation: 20,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "Hint: $hint",
                  style: const TextStyle(
                    fontSize: 20,
                    fontStyle: FontStyle.italic,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 40),
            Text(
              "Word to Guess: ${_getDisplayedWord()}",
              style: const TextStyle(fontSize: 30, color: Colors.white),
            ),
            const SizedBox(height: 30),
            Wrap(
              spacing: 10.0,
              runSpacing: 10.0,
              children: List.generate(26, (index) {
                final letter = String.fromCharCode(65 + index);
                return ElevatedButton(
                  onPressed: () => _guessLetter(letter),
                  style: ElevatedButton.styleFrom(
                    shape: const CircleBorder(),
                    backgroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
                    elevation: 5,
                    shadowColor: Colors.yellow,
                  ),
                  child: Text(
                    letter,
                    style: const TextStyle(color: Colors.yellow, fontSize: 18),
                  ),
                );
              }),
            ),
            const SizedBox(height: 40),
            Text(
              "Wrong Guesses: $wrongGuesses / 6",
              style: const TextStyle(fontSize: 20, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
class WinPage extends StatelessWidget {
  final String word;
  final String username;
  final int score;

  const WinPage({super.key, required this.word, required this.username, required this.score});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('You Win!'),
        backgroundColor: Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.yellow.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'You guessed the word: $word\n\nCongrats $username!',
                style: const TextStyle(fontSize: 24, color: Colors.yellow),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/'); // Navigate to homepage
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow.shade700, // Yellow background
                ),
                child: const Text(
                  'Play Again',
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LossPage extends StatelessWidget {
  final String word;
  final int remainingAttempts;
  final String username;
  final int score;

  const LossPage({super.key, required this.word, required this.remainingAttempts, required this.username, required this.score});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Game Over'),
        backgroundColor: Colors.black,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.yellow.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'The word was: $word\n\nYou lost the game, $username!',
                style: const TextStyle(fontSize: 24, color: Colors.yellow),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/'); // Navigate to homepage
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow.shade700, // Yellow background
                ),
                child: const Text(
                  'Play Again',
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
